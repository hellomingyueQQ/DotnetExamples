﻿using Volo.Abp;

namespace AbpBookStore.EntityFrameworkCore
{
    public abstract class AbpBookStoreEntityFrameworkCoreTestBase : AbpBookStoreTestBase<AbpBookStoreEntityFrameworkCoreTestModule> 
    {

    }
}
