﻿using System;
using System.Threading.Tasks;
using Volo.Abp.Data;
using Volo.Abp.DependencyInjection;
using Volo.Abp.Domain.Repositories;

namespace AbpBookStore
{
    public class AbpBookStoreTestDataSeedContributor : IDataSeedContributor, ITransientDependency
    {
        private readonly IRepository<Book, Guid> _bookRepository;

        public AbpBookStoreTestDataSeedContributor(
            IRepository<Book, Guid> bookRepository)
        {
            _bookRepository = bookRepository;
        }
        public async Task SeedAsync(DataSeedContext context)
        {
            /* Seed additional test data... */

            await _bookRepository.InsertAsync(
                new Book
                {
                    Name = "测试图书1",
                    Type = BookType.WebTechnology,
                    PublishDate = new DateTime(2018, 04, 24),
                    Price = 65,
                    Description = "单元测试图书"
                }
            );

            await _bookRepository.InsertAsync(
                new Book
                {
                    Name = "测试图书2",
                    Type = BookType.ITAndInternet,
                    PublishDate = new DateTime(2019, 12, 11),
                    Price = 69,
                    Description = "单元测试图书"
                }
            );
        }
    }
}