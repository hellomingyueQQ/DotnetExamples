﻿using System;
using System.ComponentModel.DataAnnotations;

namespace AbpBookStore
{
    public class CreateUpdateBookDto
    {
        [Required]
        [StringLength(128)]
        public string Name { get; set; }

        [Required]
        public BookType Type { get; set; } = BookType.WebTechnology;

        [Required]
        public DateTime PublishDate { get; set; }

        [Required]
        public float Price { get; set; }

        public string Cover { get; set; }

        public string Description { get; set; }
    }
}
