﻿using Volo.Abp.Localization;

namespace AbpBookStore.Localization
{
    [LocalizationResourceName("AbpBookStore")]
    public class AbpBookStoreResource
    {

    }
}