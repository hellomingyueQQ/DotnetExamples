﻿namespace AbpBookStore
{
    public static class AbpBookStoreConsts
    {
        public const string DbTablePrefix = "App";

        public const string DbSchema = null;
    }
}
