﻿namespace AbpBookStore.Permissions
{
    public static class AbpBookStorePermissions
    {
        public const string GroupName = "AbpBookStore";

        //Add your own permission names. Example:
        //public const string MyPermission1 = GroupName + ".MyPermission1";
    }
}