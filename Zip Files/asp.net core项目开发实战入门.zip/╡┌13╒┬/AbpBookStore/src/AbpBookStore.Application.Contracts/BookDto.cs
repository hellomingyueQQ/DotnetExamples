﻿using System;
using Volo.Abp.Application.Dtos;

namespace AbpBookStore
{
    public class BookDto : AuditedEntityDto<Guid>
    {
        public string Name { get; set; }

        public BookType Type { get; set; }

        public DateTime PublishDate { get; set; }

        public float Price { get; set; }

        public string Cover { get; set; }

        public string Description { get; set; }
    }
}
