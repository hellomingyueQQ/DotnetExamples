﻿using System;
using System.Linq;

namespace EFCoreBook
{
    class Program
    {
        static void Main(string[] args)
        {
            using (var db = new BloggingContext())
            {
                // Create
                Console.WriteLine("新增一个博客");
                db.Add(new Blog { Url = "http://blogs.msdn.com/dotnet" });
                db.SaveChanges();

                // Read
                Console.WriteLine("查询一个博客");
                var blog = db.Blogs
                    .OrderBy(b => b.BlogId)
                    .First();

                // Update
                Console.WriteLine("更新博客并添加一篇文章");
                blog.Url = "https://devblogs.microsoft.com/dotnet";
                blog.Posts.Add(
                    new Post
                    {
                        Title = "Hello World",
                        Content = "EF Core 博客!EF Core图书"
                    });
                db.SaveChanges();

                // Delete
                Console.WriteLine("删除博客");
                db.Remove(blog);
                db.SaveChanges();
            }
        }
    }
}
