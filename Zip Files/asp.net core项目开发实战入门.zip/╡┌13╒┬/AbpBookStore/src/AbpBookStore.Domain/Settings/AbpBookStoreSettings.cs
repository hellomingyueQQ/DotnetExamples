﻿namespace AbpBookStore.Settings
{
    public static class AbpBookStoreSettings
    {
        private const string Prefix = "AbpBookStore";

        //Add your own setting names here. Example:
        //public const string MySetting1 = Prefix + ".MySetting1";
    }
}