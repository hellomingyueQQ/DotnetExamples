﻿using Shouldly;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Volo.Abp.Application.Dtos;
using Volo.Abp.Validation;
using Xunit;

namespace AbpBookStore
{
    public class BookAppServiceTests:AbpBookStoreApplicationTestBase
    {
        private readonly IBookAppService _bookAppService;

        public BookAppServiceTests()
        {
            _bookAppService = GetRequiredService<IBookAppService>();
        }

        [Fact]
        public async Task Should_Get_List_Of_Books()
        {
            //操作
            var result = await _bookAppService.GetListAsync(
                new PagedAndSortedResultRequestDto()
            );

            //断言
            result.TotalCount.ShouldBeGreaterThan(0);
            result.Items.ShouldContain(b => b.Name == "测试图书1");
            result.Items.ShouldContain(b => b.Description == "单元测试图书");
        }

        [Fact]
        public async Task Should_Create_A_Valid_Book()
        {
            //操作
            var result = await _bookAppService.CreateAsync(
                new CreateUpdateBookDto
                {
                    Name = "单元测试图书",
                    Price = 80,
                    PublishDate = DateTime.Now,
                    Type = BookType.WebTechnology
                }
            );

            //断言
            result.Id.ShouldNotBe(Guid.Empty);
            result.Name.ShouldBe("单元测试图书");
        }

        [Fact]
        public async Task Should_Not_Create_A_Book_Without_Name()
        {
            var exception = await Assert.ThrowsAsync<AbpValidationException>(async () =>
            {
                await _bookAppService.CreateAsync(
                    new CreateUpdateBookDto
                    {
                        Name = "",
                        Price = 60,
                        PublishDate = DateTime.Now,
                        Type = BookType.WebTechnology
                    }
                );
            });

            //断言
            exception.ValidationErrors
                .ShouldContain(err => err.MemberNames.Any(mem => mem == "Name"));
        }
    }
}
