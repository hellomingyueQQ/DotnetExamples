﻿using Microsoft.AspNetCore.Identity;

namespace NetNote.Models
{
    public class NoteUser: IdentityUser
    {
    }
}
