﻿using Microsoft.AspNetCore.Mvc.Localization;
using Microsoft.AspNetCore.Mvc.Razor.Internal;
using AbpBookStore.Localization;
using Volo.Abp.AspNetCore.Mvc.UI.RazorPages;

namespace AbpBookStore.Web.Pages
{
    /* Inherit your UI Pages from this class. To do that, add this line to your Pages (.cshtml files under the Page folder):
     * @inherits AbpBookStore.Web.Pages.AbpBookStorePage
     */
    public abstract class AbpBookStorePage : AbpPage
    {
        [RazorInject]
        public IHtmlLocalizer<AbpBookStoreResource> L { get; set; }
    }
}
