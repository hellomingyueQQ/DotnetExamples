﻿using AutoMapper;

namespace AbpBookStore.Web
{
    public class AbpBookStoreWebAutoMapperProfile : Profile
    {
        public AbpBookStoreWebAutoMapperProfile()
        {
            //Define your AutoMapper configuration here for the Web project.
            CreateMap<BookDto, CreateUpdateBookDto>();
        }
    }
}
