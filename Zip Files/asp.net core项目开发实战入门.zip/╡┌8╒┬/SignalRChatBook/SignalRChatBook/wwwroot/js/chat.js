﻿var connection = new signalR.HubConnectionBuilder().withUrl("/chathub").build();

$("#send").disabled = true;

connection.on("ReceiveMessage", function (user, message) {
    var msg = message.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    var encodedMsg = user + " : " + msg;
    var li = document.createElement("li");
    li.textContent = encodedMsg;
    $("#messagesList").append(li);
});

connection.start().then(function () {
    $("#send").disabled = false;
}).catch(function (err) {
    return console.error(err.toString());
});

$("#send").click(function (event) {
    var user = $("#user").val();
    if (!user) {
        $("#user").addClass("is-invalid");
        return;
    } else { $("#user").removeClass("is-invalid"); }
    var message = $("#message").val();
    if (!message) {
        $("#message").addClass("is-invalid");
        return;
    } else { $("#message").removeClass("is-invalid"); }
    connection.invoke("SendMessage", user, message).catch(function (err) {
        return console.error(err.toString());
    });
    $("#message").val("");
    event.preventDefault();
});