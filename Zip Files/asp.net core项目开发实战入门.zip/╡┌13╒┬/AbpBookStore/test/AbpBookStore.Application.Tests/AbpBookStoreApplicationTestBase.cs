﻿namespace AbpBookStore
{
    public abstract class AbpBookStoreApplicationTestBase : AbpBookStoreTestBase<AbpBookStoreApplicationTestModule> 
    {

    }
}
