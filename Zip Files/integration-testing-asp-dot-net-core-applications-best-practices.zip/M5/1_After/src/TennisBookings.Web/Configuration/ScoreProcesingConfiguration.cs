﻿namespace TennisBookings.Web.Configuration
{
    public class ScoreProcesingConfiguration
    {
        public string S3BucketName { get; set; }
    }
}
