﻿$(function () {
    var l = abp.localization.getResource('AbpBookStore');

    var dataTable = $('#BooksTable').DataTable(abp.libs.datatables.normalizeConfiguration({
        ajax: abp.libs.datatables.createAjax(abpBookStore.book.getList),
        columnDefs: [
            { data: function (data) { return '<img src="' + data.cover + '" width="100px"/>'; } },
            { data: "name" },
            { data: "type" },
            { data: "publishDate" },
            { data: "price" },
            { data: "description" },
            { data: "creationTime" },
            {
                rowAction: {
                    items:
                        [
                            {
                                text: l('Actions:Edit'),
                                action: function (data) {
                                    editModal.open({ id: data.record.id });
                                }
                            },
                            {
                                text: l('Actions:Delete'),
                                confirmMessage: function (data) {
                                    return l('BookDeletionConfirmationMessage', data.record.name);
                                },
                                action: function (data) {
                                    abpBookStore.book
                                        .delete(data.record.id)
                                        .then(function () {
                                            abp.notify.info(l('SuccessfullyDeleted'));
                                            dataTable.ajax.reload();
                                        });
                                }
                            }
                        ]
                }
            }
        ]
    }));

    var createModal = new abp.ModalManager(abp.appPath + 'Books/Create');
    var editModal = new abp.ModalManager(abp.appPath + 'Books/Edit');

    createModal.onResult(function () {
        dataTable.ajax.reload();
    });

    editModal.onResult(function () {
        dataTable.ajax.reload();
    });

    $('#NewBookButton').click(function (e) {
        e.preventDefault();
        createModal.open();
    });
});
