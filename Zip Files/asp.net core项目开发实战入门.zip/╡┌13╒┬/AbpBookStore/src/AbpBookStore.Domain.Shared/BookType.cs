﻿namespace AbpBookStore
{
    public enum BookType
    {
        AI,
        MachineLearning,
        WebTechnology,
        MobileDevelopment,
        CloudComputing,
        ITAndInternet
    }
}
