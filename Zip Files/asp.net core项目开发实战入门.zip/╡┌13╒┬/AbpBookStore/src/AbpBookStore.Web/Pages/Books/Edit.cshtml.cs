using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AbpBookStore.Web.Pages.Books
{
    public class EditModel : AbpBookStorePageModel
    {
        [HiddenInput]
        [BindProperty(SupportsGet = true)]
        public Guid Id { get; set; }

        [BindProperty]
        public IFormFile CoverFile { get; set; }

        [BindProperty]
        public CreateUpdateBookDto Book { get; set; }

        private readonly IBookAppService _bookAppService;

        private readonly IWebHostEnvironment _webHostEnvironment;

        public EditModel(IBookAppService bookAppService, IWebHostEnvironment webHostEnvironment)
        {
            _bookAppService = bookAppService;
            _webHostEnvironment = webHostEnvironment;
        }

        public async Task OnGetAsync()
        {
            var bookDto = await _bookAppService.GetAsync(Id);
            Book = ObjectMapper.Map<BookDto, CreateUpdateBookDto>(bookDto);
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (CoverFile != null && CoverFile.Length > 0)
            {
                var coverFile = $"{DateTime.Now.ToString("yyyyMMddHHmmss")}{Path.GetFileName(CoverFile.FileName)}";
                var coverPath = Path.Combine(_webHostEnvironment.WebRootPath, "cover");
                if (!Directory.Exists(coverPath))
                    Directory.CreateDirectory(coverPath);
                var filePath = Path.Combine(coverPath, coverFile);
                using (var stream = System.IO.File.Create(filePath))
                {
                    await CoverFile.CopyToAsync(stream);
                }
                Book.Cover = $"/cover/{coverFile}";
            }
            await _bookAppService.UpdateAsync(Id, Book);
            return NoContent();
        }
    }
}
