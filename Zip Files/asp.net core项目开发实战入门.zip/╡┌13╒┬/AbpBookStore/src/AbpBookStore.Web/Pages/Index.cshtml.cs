﻿namespace AbpBookStore.Web.Pages
{
    public class IndexModel : AbpBookStorePageModel
    {
        public void OnGet()
        {
            
        }
    }
}