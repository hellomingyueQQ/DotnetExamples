﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using APIBook.Models;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace APIBook.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookController : Controller
    {
        private readonly BookContext _context;

        public BookController(BookContext context)
        {
            _context = context;
        }

        /// <summary>
        /// 获取所有图书
        /// </summary>
        /// <returns></returns>
        // GET: api/<controller>
        [HttpGet]
        public ActionResult<IEnumerable<BookDTO>> Get()
        {
            return _context.Books.Select(x=>BookToDTO(x)).ToList();
        }

        /// <summary>
        /// 根据id获取图书
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // GET api/<controller>/5
        [HttpGet("{id}")]
        public ActionResult<BookDTO> Get(int id)
        {
            var bookInfo = _context.Books.Find(id);

            if (bookInfo == null)
            {
                return NotFound();
            }

            return BookToDTO(bookInfo);
        }

        /// <summary>
        /// 添加图书
        /// </summary>
        /// <remarks>
        /// 示例参数：
        /// {"Title":"ASP.NET Core开发实战","Author":"zhangjq","PublicationDate":"2020-05-01"}
        /// </remarks>
        /// <param name="book"></param>
        /// <returns></returns>
        /// <response code="201">返回新建项</response>  
        [HttpPost]
        public IActionResult Post(Book book)
        {
            _context.Books.Add(book);
            _context.SaveChanges();
            return CreatedAtAction(nameof(Get), new { id = book.Id }, book);
        }

        /// <summary>
        /// 更新图书
        /// </summary>
        /// <param name="id"></param>
        /// <param name="book"></param>
        /// <returns></returns>
        // PUT api/<controller>/5
        [HttpPut("{id}")]
        public IActionResult Put(int id, Book book)
        {
            if (id != book.Id)
                return BadRequest();
            var bookInfo = _context.Books.Find(id);

            if (bookInfo == null)
            {
                return NotFound();
            }
            bookInfo.Title = book.Title;
            bookInfo.Author = book.Author;
            bookInfo.PublicationDate = book.PublicationDate;
            _context.SaveChanges();
            return CreatedAtAction(nameof(Get), new { id = book.Id }, bookInfo);
        }

        /// <summary>
        /// 删除图书
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // DELETE api/<controller>/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var bookInfo = _context.Books.Find(id);

            if (bookInfo == null)
            {
                return NotFound();
            }
            _context.Books.Remove(bookInfo);
            _context.SaveChanges();
            return NoContent();
        }

        private static BookDTO BookToDTO(Book book) =>
            new BookDTO
            {
                Id = book.Id,
                Title = book.Title,
                PublicationDate = book.PublicationDate
            };
    }
}
