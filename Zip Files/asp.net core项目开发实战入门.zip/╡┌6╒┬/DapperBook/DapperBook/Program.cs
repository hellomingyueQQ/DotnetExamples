﻿using System;
using Microsoft.Data.Sqlite;
using Dapper;
using System.IO;

namespace DapperBook
{
    class Program
    {
        static string s_conStr = "Filename=dapper.db";
        static void Main(string[] args)
        {
            CreateDatabase();

            using (SqliteConnection con = new SqliteConnection(s_conStr))
            {
                //新增数据
                con.Execute("INSERT INTO EMPLOYEE VALUES(@Id,@Name,@Age,@Address,@Salary)"
                    ,new Employee { Id=1,Name="aspnetcore",Age=4,Address="aspnetcore book",Salary=88 });
                //查询获取第一条数据
                var employee = con.QueryFirst<Employee>("SELECT * FROM EMPLOYEE");
                //修改数据
                con.Execute("UPDATE EMPLOYEE SET Name = 'netcore' WHERE ID = @Id", new { Id = employee.Id });
                //查询数据
                var list = con.Query<Employee>("SELECT * FROM EMPLOYEE");
                foreach (var item in list)
                {
                    Console.WriteLine($"员工：{item.Name} 年龄：{item.Age}地址：{item.Address}");
                }
                //删除数据
                var result=con.Execute("DELETE FROM EMPLOYEE WHERE ID = @Id", new { Id = employee.Id });
                Console.WriteLine($"删除影响行数：{result}");
                Console.WriteLine("删除数据后的结果");
                var count = con.QueryFirst<int>("SELECT COUNT(*) FROM EMPLOYEE");
                Console.WriteLine($"数据行数：{count}");
                //批量新增数据
                con.Execute("INSERT INTO EMPLOYEE VALUES(@Id,@Name,@Age,@Address,@Salary)"
                    , new Employee[] { new Employee { Id = 1, Name = "aspnetcore", Age = 4, Address = "aspnetcore book", Salary = 88 },
                    new Employee { Id = 2, Name = "aspnetcore 3.0", Age = 1, Address = "aspnetcore 3.0 book", Salary = 88 }});
                //Linq 支持
                count = con.QueryFirst<int>("SELECT COUNT(*) FROM EMPLOYEE WHERE ID IN @Ids", new { Ids =new int[] { 1, 2 } });
                Console.WriteLine($"数据行数：{count}");
            }

            Console.ReadKey();
        }

        private static void CreateDatabase() 
        {
            //如果存在则清理
            if (File.Exists("dapper.db")) 
                File.Delete("dapper.db");
            using (var con=new SqliteConnection(s_conStr))
            {
                con.Execute(@"CREATE TABLE EMPLOYEE(
   ID INT PRIMARY KEY     NOT NULL,
   NAME           TEXT    NOT NULL,
   AGE            INT     NOT NULL,
   ADDRESS        CHAR(50),
   SALARY         REAL
);");
            }
        }
    }
}
