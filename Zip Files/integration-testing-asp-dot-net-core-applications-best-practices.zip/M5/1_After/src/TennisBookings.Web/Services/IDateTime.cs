﻿using System;

namespace TennisBookings.Web.Services
{
    public interface IDateTime
    {
        DateTime DateTimeUtc { get; }
    }
}
