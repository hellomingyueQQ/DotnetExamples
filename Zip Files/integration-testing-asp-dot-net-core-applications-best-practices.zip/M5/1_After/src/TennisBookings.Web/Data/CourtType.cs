﻿namespace TennisBookings.Web.Data
{
    public enum CourtType
    {
        Indoor,
        Outdoor
    }
}