﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace APIBook.Models
{
    /// <summary>
    /// 图书
    /// </summary>
    public class Book
    {
        /// <summary>
        /// Id
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// 标题
        /// </summary>
        public string Title { get; set; }
        /// <summary>
        /// 作者
        /// </summary>
        public string Author { get; set; }
        /// <summary>
        /// 出版日期
        /// </summary>
        public DateTime PublicationDate { get; set; }
    }

    /// <summary>
    /// 图书DTO
    /// </summary>
    public class BookDTO
    {
        /// <summary>
        /// Id
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// 标题
        /// </summary>
        public string Title { get; set; }
        /// <summary>
        /// 出版日期
        /// </summary>
        public DateTime PublicationDate { get; set; }
    }
}
