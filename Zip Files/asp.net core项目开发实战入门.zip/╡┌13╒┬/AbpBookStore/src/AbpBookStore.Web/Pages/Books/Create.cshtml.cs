using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AbpBookStore.Web.Pages.Books
{
    public class CreateModel : AbpBookStorePageModel
    {
        [BindProperty]
        public IFormFile CoverFile { get; set; }

        [BindProperty]
        public CreateUpdateBookDto Book { get; set; }

        private readonly IBookAppService _bookAppService;
        private readonly IWebHostEnvironment _webHostEnvironment;

        public CreateModel(IBookAppService bookAppService, IWebHostEnvironment webHostEnvironment)
        {
            _bookAppService = bookAppService;
            _webHostEnvironment = webHostEnvironment;
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (CoverFile != null && CoverFile.Length > 0)
            {
                var coverFile = $"{DateTime.Now.ToString("yyyyMMddHHmmss")}{Path.GetFileName(CoverFile.FileName)}";
                var coverPath = Path.Combine(_webHostEnvironment.WebRootPath, "cover");
                if (!Directory.Exists(coverPath))
                    Directory.CreateDirectory(coverPath);
                var filePath = Path.Combine(coverPath, coverFile);
                using (var stream = System.IO.File.Create(filePath))
                {
                    await CoverFile.CopyToAsync(stream);
                }
                Book.Cover = $"/cover/{coverFile}";
            }
            await _bookAppService.CreateAsync(Book);
            return NoContent();
        }
    }
}
