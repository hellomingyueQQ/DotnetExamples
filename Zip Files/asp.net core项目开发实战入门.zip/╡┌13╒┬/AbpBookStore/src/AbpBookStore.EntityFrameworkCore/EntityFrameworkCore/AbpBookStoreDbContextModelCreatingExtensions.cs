﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Volo.Abp;
using Volo.Abp.EntityFrameworkCore.Modeling;
using Volo.Abp.Users;

namespace AbpBookStore.EntityFrameworkCore
{
    public static class AbpBookStoreDbContextModelCreatingExtensions
    {
        public static void ConfigureAbpBookStore(this ModelBuilder builder)
        {
            Check.NotNull(builder, nameof(builder));

            /* Configure your own tables/entities inside here */

            //builder.Entity<YourEntity>(b =>
            //{
            //    b.ToTable(AbpBookStoreConsts.DbTablePrefix + "YourEntities", AbpBookStoreConsts.DbSchema);

            //    //...
            //});
            builder.Entity<Book>(b =>
            {
                b.ToTable(AbpBookStoreConsts.DbTablePrefix + "Books", AbpBookStoreConsts.DbSchema);
                b.ConfigureByConvention(); //auto configure for the base class props
                b.Property(x => x.Name).IsRequired().HasMaxLength(128);
            });
        }

        public static void ConfigureCustomUserProperties<TUser>(this EntityTypeBuilder<TUser> b)
            where TUser: class, IUser
        {
            //b.Property<string>(nameof(AppUser.MyProperty))...
        }
    }
}