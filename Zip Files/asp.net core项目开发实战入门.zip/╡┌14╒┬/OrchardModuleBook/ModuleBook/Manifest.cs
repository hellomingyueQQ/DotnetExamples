using OrchardCore.Modules.Manifest;

[assembly: Module(
    Name = "ModuleBook",
    Author = "The Orchard Team",
    Website = "https://orchardproject.net",
    Version = "0.0.1",
    Description = "ģ��ʾ��",
    Category = "ModuleBook"
)]
