﻿using Microsoft.AspNetCore.Identity;

namespace TennisBookings.Web.Data
{
    public class TennisBookingsRole : IdentityRole
    {
    }
}