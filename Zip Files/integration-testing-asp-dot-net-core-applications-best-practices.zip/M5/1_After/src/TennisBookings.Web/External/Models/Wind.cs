﻿namespace TennisBookings.Web.External.Models
{
    public class Wind
    {
        public float Speed { get; set; }
        public float Degrees { get; set; }
    }
}
