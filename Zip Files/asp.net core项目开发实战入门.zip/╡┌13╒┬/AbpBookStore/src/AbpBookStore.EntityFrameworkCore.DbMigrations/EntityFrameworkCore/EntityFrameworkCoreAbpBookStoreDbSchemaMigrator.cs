﻿using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using AbpBookStore.Data;
using Volo.Abp.DependencyInjection;

namespace AbpBookStore.EntityFrameworkCore
{
    [Dependency(ReplaceServices = true)]
    public class EntityFrameworkCoreAbpBookStoreDbSchemaMigrator 
        : IAbpBookStoreDbSchemaMigrator, ITransientDependency
    {
        private readonly AbpBookStoreMigrationsDbContext _dbContext;

        public EntityFrameworkCoreAbpBookStoreDbSchemaMigrator(AbpBookStoreMigrationsDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task MigrateAsync()
        {
            await _dbContext.Database.MigrateAsync();
        }
    }
}