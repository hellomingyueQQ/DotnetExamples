﻿using System;
using System.Threading.Tasks;
using GrpcBook;
using Grpc.Net.Client;
using Grpc.Core;
using System.Diagnostics;

namespace GrpcBookClient
{
    class Program
    {
        static async Task Main(string[] args)
        {
            // 端口号（5001）必须与gRPC服务器的端口匹配
            using var channel = GrpcChannel.ForAddress("https://localhost:5001");
            var client = new Greeter.GreeterClient(channel);
            var reply = await client.SayHelloAsync(
                              new HelloRequest { Name = "GrpcBook客户端" });
            Console.WriteLine("GrpcBook服务端应答: " + reply.Message);
            
            // 赛车手
            Console.WriteLine("Press any key to start race...");
            Console.ReadKey();
            var racerClient = new Racer.RacerClient(channel);
            await BidirectionalStreamingExample(racerClient);

            Console.WriteLine("Shutting down");
            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }

        private static async Task BidirectionalStreamingExample(Racer.RacerClient client)
        {
            var RaceDuration = TimeSpan.FromSeconds(3);
            var headers = new Metadata { new Metadata.Entry("race-duration", RaceDuration.ToString()) };

            Console.WriteLine("Ready, set, go!");
            using (var call = client.ReadySetGo(new CallOptions(headers)))
            {

                // 读取传入信息后台任务
                RaceMessage? lastMessageReceived = null;
                var readTask = Task.Run(async () =>
                {
                    await foreach (var message in call.ResponseStream.ReadAllAsync())
                    {
                        lastMessageReceived = message;
                    }
                });

                // 写入信息直到计时结束
                var sw = Stopwatch.StartNew();
                var sent = 0;
                while (sw.Elapsed < RaceDuration)
                {
                    await call.RequestStream.WriteAsync(new RaceMessage { Count = ++sent });
                }

                // 完成整个请求展示结果
                await call.RequestStream.CompleteAsync();
                await readTask;

                Console.WriteLine($"消息发送次数: {sent}");
                Console.WriteLine($"消息接收次数: {lastMessageReceived?.Count ?? 0}");
            }
        }
    }
}
