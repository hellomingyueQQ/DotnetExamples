﻿namespace AbpBookStore
{
    public static class AbpBookStoreDomainErrorCodes
    {
        /* You can add your business exception error codes here, as constants */
    }
}
