﻿using Volo.Abp.Http.Client.IdentityModel;
using Volo.Abp.Modularity;

namespace AbpBookStore.HttpApi.Client.ConsoleTestApp
{
    [DependsOn(
        typeof(AbpBookStoreHttpApiClientModule),
        typeof(AbpHttpClientIdentityModelModule)
        )]
    public class AbpBookStoreConsoleApiClientModule : AbpModule
    {
        
    }
}
