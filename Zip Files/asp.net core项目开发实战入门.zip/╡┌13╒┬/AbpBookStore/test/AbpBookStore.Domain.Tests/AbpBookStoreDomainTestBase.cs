﻿namespace AbpBookStore
{
    public abstract class AbpBookStoreDomainTestBase : AbpBookStoreTestBase<AbpBookStoreDomainTestModule> 
    {

    }
}
